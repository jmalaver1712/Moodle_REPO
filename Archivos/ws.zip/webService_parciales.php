<?php


$ws['ObtenerCalificacionesParciales'] = 
array('ObtenerCalificacionesParciales' => //Nombre del metodo
array('entrada' =>  //Parametros de entrada
	array(
	'per_aca' => 	array('name' =>'per_aca','type' => 'xsd:int','operador'=>'='),
	'codigo_curso' => 	array('name' =>'codigo_curso','type' => 'xsd:int','operador'=>'='),
	'codigo_estudiante'	=> 	array('name'=>'codigo_estudiante','type'=>'xsd:int','operador'=>'='),
	// 'calificacion' => array('name' =>'calificacion','type' => 'xsd:decimal','operador'=>'<='),
	)
,
'salida' =>  //Parametros de Salida
	array(
	'per_aca'=>array('minOccurs'=>'1','type'=>'xsd:int','default'=>'0'),
	'codigo_curso'=>array('minOccurs'=>'1','type'=>'xsd:int','default'=>'0'),
	'nombre_curso'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'0'),
	'codigo_estudiante'=>array('minOccurs'=>'1','type'=>'xsd:int','default'=>'0'),
	'nombres'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'0'),
	'apellidos'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'0'),
	'f_inicio'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'No_Aplica'),
	'f_final'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'No_Aplica'),
	'f_presentacion'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'No_Aplica'),
	'actividad'=>array('minOccurs'=>'1','type'=>'xsd:string','default'=>'0'),
	'nota_max'=>array('minOccurs'=>'1','type'=>'xsd:int','default'=>'0'),
	'nota_obtenida'=>array('minOccurs'=>'1','type'=>'xsd:int','default'=>'0'),
	), 
'tabla' => 'am_calificaciones_parciales',
'arreglo'=>'Calificaciones_Parciales'
),
);	


