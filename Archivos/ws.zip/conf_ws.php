<?php

define('DB_HOST','localhost');
define('DB_USER','campusvi_campus');
define('DB_PASSWORD','campus_urep.2016');
define('DB_NAME','campusvi_md_aulas');
define('AUTH_USER','admin');
define('AUTH_PASS','pass');
