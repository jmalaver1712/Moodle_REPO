<?php
session_start();

ini_set("memory_limit","512M");
require_once("lib/nusoap.php");
$path = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'];
$ns = (!isset($_REQUEST["fileWs"]))? 
$path:
str_replace (basename($path),"",$path).$_REQUEST["fileWs"];
$_SESSION['ns']=$ns;
//print $ns;

$serviceName ='Corporación Universitaria Republicana';
$server = new soap_server();


$server->configureWSDL($serviceName,$ns);
$server->wsdl->schemaTargetNamespace=$ns;
$server->xml_encoding = "utf-8";
$server->soap_defencoding = "utf-8";

function generaWS($ws){
	global $server;
	global $ns;	
	global $serviceName;
        //die ($ns);
	foreach ($ws as $metodo => $parametros) {
   // SIMPLE TYPE
        $server->wsdl->addSimpleType( 
            'IdentificadorIndicador',
            'xsd:string',
            'SimpleType',
            'scalar',
            array( 
                'uno',
                'dos',
                'tres'
                )
            );    
        // print_r($parametros);
        //            
        //print $parametros['arreglo'];
        //exit();
        $server->wsdl->addComplexType('ArrayOf'.$parametros['arreglo'],
                //$server->wsdl->addComplexType('ArrayOf'.$metodo,
            'complexType',
            'struct',
            'all',
            '',
                $parametros["salida"]);   //Configuramos el parametro de Entrada del WS




        $server->wsdl->addComplexType('consolidado'.$metodo,
            'complexType',
            'array',
            '',
            'SOAP-ENC:Array',
            array(),
            array(array('ref' => 'SOAP-ENC:arrayType', 'wsdl:arrayType' => 'tns:'.'ArrayOf'.$parametros['arreglo'].'[]')), 'tns:'.'ArrayOf'.$parametros['arreglo']);
            //array(array('ref' => 'SOAP-ENC:arrayType', 'wsdl:arrayType' => 'tns:'.'ArrayOf'.$metodo.'[]')), 'tns:'.'ArrayOf'.$metodo);




        $entrada= '$arr = array(';
        foreach ($parametros["entrada"] as $key => $value){
            $entrada.= "'".$value['name']."'=>'".$value['type']."',";
        }
        $entrada = substr($entrada, 0, -1).");";
        eval($entrada);

        $server->register($metodo,$arr,
            array(''.$metodo => 'tns:consolidado'.$metodo),$ns);
        //array('resultado'.$metodo => 'tns:consolidado'.$metodo),$ns);
        $consulta = "SELECT ";
        foreach ($parametros["salida"] as $key => $value) $consulta.= $key.",";
        $consulta = substr($consulta, 0, -1);
        $consulta.= " FROM ". $parametros["tabla"];

        $p="";
        foreach ($parametros["entrada"] as $key => $value) $p.= '$'.$key."=NULL,"; 
        $p = substr($p, 0, -1);

        $function = '
        function '.$metodo.'('.$p.') {
            global $ws;
            $params = get_func_argNames("'.$metodo.'");
            $where = false;
            $operador ="";
            foreach ($params as $key=> $value){
                $operador = $ws["'.$metodo.'"]["'.$metodo.'"]["entrada"][$value][operador];
                $entrada  = $ws["'.$metodo.'"]["'.$metodo.'"]["entrada"][$value];   
                if (!empty($$value))
                    $where.="$value".$operador."\'".$$value."\' and ";
                elseif (!empty($entrada["condicion"])){
                    $where.="$value ".$entrada["condicion"]." and ";
                }
            }

            $where = ($where)?  " WHERE ".substr($where, 0, -4):NULL;
            $consulta = "'.$consulta.'".$where;

            return consultaWS($consulta); }';
            eval ($function);
            //echo $function;
            //print "<br>";

        }
    }



    function consultaWS($sql){

        require_once('conf_ws.php');

        $link = mysql_connect(DB_HOST, DB_USER,DB_PASSWORD)  or die('No se pudo conectar: ' . mysql_error());
        mysql_select_db(DB_NAME) or die('No se pudo seleccionar la base de datos');
        $res=mysql_query($sql,$link);
        
        if($res) while($row=  mysql_fetch_array($res)) $xml[]=$row;
        //  print_r($xml);
        //  print $sql;
        //	exit();
        mysql_close($link);

        return $xml;    


    }

    function get_func_argNames($funcName) {
        $f = new ReflectionFunction($funcName);
        $result = array();
        foreach ($f->getParameters() as $param) {
            $result[] = $param->name;   
        }
        return $result;
    }

/////////////////////////////////////////////////// PARAMETRIZACION DE LOS WS  ////////////////////////////////////////////////		
    include("webService_estudiante.php");



    foreach ($ws as $webService) 
       generaWS($webService);	


   if ( !isset( $HTTP_RAW_POST_DATA ) ) $HTTP_RAW_POST_DATA =file_get_contents( 'php://input' );
   $server->service($HTTP_RAW_POST_DATA);


   ?>

