<?php
//error_reporting(E_ALL ^E_NOTICE ^E_DEPRECATED);
//ini_set('display_errors','on');

ini_set("memory_limit","256M");

$options = array(
// Stuff for development.
'trace' => true,
'exceptions' => true,
'cache_wsdl' => WSDL_CACHE_NONE,
'features' => SOAP_SINGLE_ELEMENT_ARRAYS +  SOAP_USE_XSI_ARRAY_TYPE,
'soap_version'   => SOAP_1_2,
'soap_action' => 'show',
// Auth credentials for the SOAP request.
'login' => "admin",
'password' =>"pass",
//'Authorization' => 123456,
'language' => 'es',
'encoding'=>'UTF-8');

try {
	$soap = new SoapClient('http://localhost:1001/mgm_kvdplus/modulos/ws/soap.php?wsdl', $options);
	$data = $soap->ObtenerNivelSatisfaccionUsuario('','2016-01-01');
}
catch(Exception $e) {
	die($e->getMessage());
}
  
//$x=var_dump($data);
print_r($data);
die;




?>

